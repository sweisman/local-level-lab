# SPDX-License-Identifier: AGPL-3.0-or-later
"""Check exact printed-clock arithmetic and strict byte record boundaries."""

import pytest

from lll.esa_girafe_platform_probe import ROW_BYTES, inspect_block


def sample(index, *, time_shift=0.):
    time = f'{696.8154+index/1024+time_shift:011.4f}'
    rest = '   -0.162986 -0.394864 -9.761379   -01.20857 +00.02136 -00.01741\r\n'
    raw = (time+rest).encode()
    assert len(raw) == ROW_BYTES
    return raw


def test_lattice_binds_printed_timestamps_to_the_original_row_index():
    first = 100_000
    raw = b''.join(sample(first+i) for i in range(128))
    row = inspect_block(raw, first, expected_rows=128)
    assert row['first_row'] == first and row['last_row'] == first+127
    assert row['local_rounding_compatible']
    assert set(row['step_counts_0p1ms']) == {'9', '10'}
    assert row['phase_min_64ths_tick'] <= 6968154*64 <= row['phase_max_64ths_tick']+32


def test_valid_rows_can_have_an_incompatible_uniform_clock():
    raw = sample(0)+sample(1, time_shift=.01)+sample(2, time_shift=.01)
    assert not inspect_block(raw, 0, expected_rows=3)['local_rounding_compatible']


def test_broken_width_delimiters_or_chronology_fail():
    for data in (sample(0)+sample(1)[:-1], sample(0).replace(b'   ', b' \n ', 1)+sample(1),
                 sample(1)+sample(0)):
        with pytest.raises(ValueError):
            inspect_block(data, 0, expected_rows=2)
