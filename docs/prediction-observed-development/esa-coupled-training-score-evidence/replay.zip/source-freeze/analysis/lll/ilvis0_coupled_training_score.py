# SPDX-License-Identifier: AGPL-3.0-or-later
"""Proposal and certificate for a loss ball with static calibration cuts."""

from fractions import Fraction as F

import numpy as np

from .ilvis0_affine_support import linear_proposal
from .ilvis0_linked_training_support import training_upper
from .ilvis0_saved_prediction_audit import endpoint


def translate_rows(rows, bounds, center):
    """Translate cuts on absolute parameters to displacements from the fit."""
    center = tuple(map(F, center))
    return [endpoint(F(b)-sum(F(a)*c for a, c in zip(row, center, strict=True)), True)
            for row, b in zip(rows, bounds, strict=True)]


def propose(design, residual, lower, upper, objective, static, static_upper, *,
            radius, iterations, seed):
    """Generate loss-ball cuts in floating point and return proposal weights."""
    cuts, limits = list(static), list(static_upper)
    vectors = []
    candidate = np.asarray(seed, float)
    best = dict(approximate_upper=float('inf'), direction=np.zeros_like(residual),
                weights=np.zeros(len(static)), iterations=0)
    for _ in range(iterations):
        row = design.T @ candidate
        scale = max(1., np.max(abs(row)))
        vectors.append(candidate/scale)
        cuts.append(row/scale)
        limits.append((radius*np.linalg.norm(candidate)-residual@candidate)/scale)
        fit = linear_proposal(lower, upper, cuts, limits, objective)
        if fit is None:
            break
        x, dual = fit
        norm_direction = np.asarray(vectors).T @ dual[len(static):]
        weights = dual[:len(static)]
        # Bound proposal quality after combining the norm directions. The
        # certificate will rebuild this bound using exact coefficient intervals.
        remaining = objective - np.asarray(static).T@weights - design.T@norm_direction
        score = (radius*np.linalg.norm(norm_direction) - residual@norm_direction
                 + np.asarray(static_upper)@weights
                 + np.maximum(remaining*lower, remaining*upper).sum())
        if score < best['approximate_upper']:
            best.update(approximate_upper=float(score), direction=norm_direction, weights=weights)
        best['iterations'] += 1
        candidate = residual + design@np.clip(x, lower, upper)
        if np.linalg.norm(candidate) <= radius:
            break
    return best


def certify(residual, direction, training, objective, lower, upper,
            static, static_upper, weights, *, increase, unshared):
    """Check dual numbers using only outward coefficients and exact arithmetic."""
    weights = tuple(map(F, weights))
    if any(weight<0 for weight in weights) or len(weights)!=len(static):
        raise ValueError('nonnegative weight for every static inequality required')
    result = training_upper(residual, direction, increase=increase, unshared=unshared)
    result += sum(weight*F(bound) for weight, bound in zip(weights, static_upper, strict=True))
    for i, (lo, hi, (a, b), (c, d)) in enumerate(zip(lower, upper, training, objective, strict=True)):
        if not lo<=0<=hi or a>b or c>d:
            raise ValueError('ordered interval coefficients and a box containing zero required')
        shift = sum(weight*F(row[i]) for weight, row in zip(weights, static, strict=True) if weight)
        result += max(F(lo)*(c-b-shift), F(hi)*(d-a-shift))
    return result
