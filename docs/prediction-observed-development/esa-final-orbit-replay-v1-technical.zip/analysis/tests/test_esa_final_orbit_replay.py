# SPDX-License-Identifier: AGPL-3.0-or-later
import pytest

from lll.esa_final_orbit_replay import interpolate_orbit


def test_interpolation_matches_a_known_degree_seven_polynomial():
    def position(t):
        u = t / 900
        return (2.0 + u**7 / 100, 4.0 - u**4, -5.0 + u**3)

    knots = {i * 900: position(i * 900) for i in range(-3, 5)}
    assert interpolate_orbit(knots, 387.3) == pytest.approx(position(387.3), abs=1e-11)
    assert interpolate_orbit(knots, 0.) == knots[0]
    del knots[1800]
    with pytest.raises(ValueError, match='missing'):
        interpolate_orbit(knots, 387.3)
