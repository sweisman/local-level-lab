# SPDX-License-Identifier: AGPL-3.0-or-later
"""Directional bounds with physical and shared errors in one training constraint."""

from fractions import Fraction

import numpy as np
from scipy.optimize import minimize

from .ilvis0_exact_scale import sqrt_upper
from .ilvis0_saved_prediction_audit import endpoint


def propose_direction(design, residual, objective, lower, upper, radius):
    """Suggest a dual direction. Its quality has no bearing on validity."""
    baseline = residual @ residual
    ceiling = (radius - np.sqrt(baseline)) * (radius + np.sqrt(baseline))
    linear = residual @ design
    recent = max(float(ceiling), 1e-12)
    scale = max(np.linalg.norm(objective), 1e-12)

    def gap(point):
        change = design @ point
        return (ceiling - 2 * linear @ point - change @ change) / recent

    result = minimize(
        lambda x: -(objective @ x) / scale, np.zeros(len(objective)),
        method='SLSQP', jac=lambda _: -objective / scale,
        bounds=list(zip(lower, upper, strict=True)),
        constraints=[dict(type='ineq', fun=gap,
                          jac=lambda x: -2 * (linear + design.T @ (design @ x)) / recent)],
        options=dict(maxiter=200, ftol=1e-10),
    )
    direction = residual + design @ np.clip(result.x, lower, upper)
    return direction, bool(result.success)


def support(residual, direction, training, objective, lower, upper, *, increase, unshared):
    """Enclose the support of the enlarged training ball intersected with the box.

    Training and objective coefficients are supplied as exact intervals. For
    any nonnegative multiplier, Cauchy-Schwarz gives a necessary projected
    training inequality. Maximize the remaining linear form over the box.
    Optimize that bound by checking its piecewise linear breakpoints.
    """
    residual, direction, lower, upper = (tuple(map(Fraction, values))
                                         for values in (residual, direction, lower, upper))
    increase, unshared = Fraction(increase), Fraction(unshared)
    if len(residual) != len(direction) or increase <= 0 or unshared < 0:
        raise ValueError('aligned training vectors and finite nonnegative budgets required')
    radius = Fraction(sqrt_upper(sum(v*v for v in residual) + increase)) + unshared
    bound = radius * Fraction(sqrt_upper(sum(v*v for v in direction)))
    bound -= sum(x*y for x, y in zip(residual, direction, strict=True))
    lines = []
    candidates = {Fraction(0)}
    for lo, hi, (a, b), (c, d) in zip(lower, upper, training, objective, strict=True):
        if not lo <= 0 <= hi or a > b or c > d:
            raise ValueError('ordered interval coefficients and box containing zero required')
        left, right = lo*c, hi*d
        left_slope, right_slope = -lo*b, -hi*a
        lines.append((left, right, left_slope, right_slope))
        if left_slope != right_slope:
            crossing = (right - left) / (left_slope - right_slope)
            if crossing > 0:
                candidates.add(crossing)

    def upper_at(multiplier):
        return multiplier * bound + sum(
            max(left + multiplier*left_slope, right + multiplier*right_slope)
            for left, right, left_slope, right_slope in lines
        )

    exact, multiplier = min((upper_at(value), value) for value in candidates)
    return dict(upper=endpoint(exact, True), exact_upper=str(exact),
                box_upper=endpoint(upper_at(0), True), multiplier=str(multiplier))
