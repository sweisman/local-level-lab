# Sealed force calibration score bounds

[Method and results](../ESA_FORCE_SCORE_RESULT.md).
