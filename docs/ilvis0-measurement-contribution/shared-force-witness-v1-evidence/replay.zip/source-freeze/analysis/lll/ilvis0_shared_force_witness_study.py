# SPDX-License-Identifier: AGPL-3.0-or-later
"""Check a common GPS receiver error on two saved NASA force histories."""

from contextlib import closing
import json
from pathlib import Path


ID = 'ilvis0-shared-force-witness-v1-20261120'
SCOPE = 'One shared receiver-error example for the saved matched NASA force inequalities'
PLAN = 'docs/ilvis0-measurement-contribution/SHARED_FORCE_WITNESS_PLAN.md'
WINDOWS = {'8': 608, '21': 383}
PER_WINDOW = 8
STEPS = 64
PROPOSAL_MARGIN = .00001


def tasks():
    return [dict(identity='imu'+imu, input_key='imu'+imu, payload=dict(imu_type=imu),
                 limits=dict(native_calls=0, packet_visits=0, bound_calls=3,
                             bound_steps=2*PER_WINDOW*count+STEPS)) for imu, count in WINDOWS.items()]


def evaluate(task, context):
    import numpy as np
    from scipy.sparse import csr_matrix

    from . import ilvis0_matched_force_average as average
    from . import ilvis0_matched_force_covariance as covariance
    from .ilvis0_error_model import Spec
    from .ilvis0_shared_force_witness import project_witness
    from .ilvis0_solver_position import physical_metric

    declared = {key: value for key, value in task.items() if key not in ('index', 'shard')}
    if declared not in tasks() or context.manifest['scope'] != SCOPE:
        raise ValueError('exact archived gyro-free witness tasks required')
    material = json.loads(context.input_path().read_bytes())
    imu = task['payload']['imu_type']
    times, tags, coordinates = (np.asarray(material[key]) for key in ('times', 'tags', 'coordinates'))
    windows = material['windows']
    models = average.MATCHED_MODELS
    if (imu != material['imu_type'] or len(windows) != WINDOWS[imu] or coordinates.shape != (len(times), 3)
            or len(tags) != len(times) or not np.isfinite(coordinates).all() or np.any(np.diff(tags) <= 0)
            or len(models)*len(average.support.CLOCKS) != PER_WINDOW or set(material['gains']) != set(models)):
        raise ValueError('full matched GPS and accelerometer window history required')
    metric = physical_metric(coordinates)
    shared = np.diag(np.square(covariance.SHARED_SIGMA))
    law = Spec(np.diag(np.square(covariance.WHITE_SIGMA)), ((covariance.TAU_S, shared),),
               shared, shared, times[0], times[-1]-times[0])
    columns, values, boundaries, sigma, deficit, layout = [], [], [0], [], [], []
    context.charge(bound_calls=1, bound_steps=PER_WINDOW*len(windows))
    for window in windows:
        first, last, target = window['first'], window['last'], window['target']
        stop = last+1
        train = stop <= material['cut']
        if (not 0 <= first <= target <= last < len(times) or stop-first != window['sample_count']
                or first < material['cut'] < stop or train != (window['side'] == 'training')):
            raise ValueError('window differs from its saved contiguous split')
        support = slice(first, stop)
        weights = average.quadratic_weights((tags[support]-tags[target])/1000.)
        local = coordinates[support].copy()
        local[:, 1] = np.unwrap(local[:, 1])
        jet = weights @ local
        for clock in average.support.CLOCKS:
            clock_row = window['clocks'][clock]
            interval = clock_row['interval']
            gradients = covariance.weights_for_interval(jet, weights, interval)[:len(models)]
            gradients = gradients.reshape((len(models), stop-first, 3))/metric[support]
            for model, row in zip(models, gradients, strict=True):
                low = clock_row['acceleration_lower_mps2']/(1.+material['gains'][model])
                high = clock_row['prediction_upper_mps2'][model]
                columns.extend(range(3*first, 3*stop))
                values.extend(row.ravel())
                boundaries.append(len(values))
                sigma.append(clock_row['sigma_mps2'][model])
                deficit.append(low-np.nextafter(high, np.inf))
                layout.append((model, clock, window['side'], int(tags[target]), interval, support, weights, low))
    matrix = csr_matrix((values, columns, boundaries), shape=(len(layout), 3*len(times)))
    deficits = np.asarray(deficit)
    proposal = np.where(deficits > 0., deficits+PROPOSAL_MARGIN, deficits)
    context.charge(bound_calls=1, bound_steps=STEPS)
    witness = project_witness(times, law, matrix, proposal, sigma, maximum_steps=STEPS)
    correction = witness.pop('error_m').reshape((-1, 3))
    context.save('receiver-error.json', dict(times_s=times.tolist(), axes=['north', 'east', 'up'],
                 correction_m=correction.tolist(), projected=matrix.dot(correction.ravel()).tolist(), **witness))
    adjusted = coordinates + correction/metric
    rows = []
    time_offset = average.support.TIME_OFFSET_S
    context.charge(bound_calls=1, bound_steps=PER_WINDOW*len(windows))
    for before, (model, clock, side, tag, interval, support, weights, low) in zip(deficit, layout, strict=True):
        local = adjusted[support].copy()
        local[:, 1] = np.unwrap(local[:, 1])
        predicted_lo, predicted_hi = average.bound_average(weights @ local, interval,
            offset_bounds_s=(-time_offset, time_offset), subdivisions=average.SUBDIVISIONS,
            model=model, background_rate_rads=average.rate(model), gravity_mps2=average.GRAVITY,
            disc_radius_m=average.RADIUS)
        rows.append(dict(model=model, clock=clock, side=side, gps_tag=tag, initial_deficit_mps2=float(before),
            reconstructed_deficit_mps2=float(low-np.nextafter(predicted_hi, np.inf)),
            reconstructed_stronger_deficit_mps2=float(low-np.nextafter(predicted_lo, np.inf))))
    context.save('inequalities.json', rows)
    return dict(passed=True, imu_type=imu, inequalities=len(rows),
                initial_violations=sum(bool(row['initial_deficit_mps2'] > 0.) for row in rows),
                remaining_violations=sum(bool(row['reconstructed_deficit_mps2'] > 0.) for row in rows),
                remaining_stronger=sum(bool(row['reconstructed_stronger_deficit_mps2'] > 0.) for row in rows),
                largest_position_correction_m=float(np.max(np.linalg.norm(correction, axis=1))),
                **witness, fit_starts=0, gyro_observations_used=False, scientific_decision='abstain')


def prepare(root):
    import numpy as np

    from . import ilvis0_matched_force_average as average
    from . import ilvis0_matched_force_covariance as covariance
    from . import ilvis0_matched_force_gain as gain
    from .studies.artifacts import ArchiveStore, atomic, digest, encoded
    from .studies.dependencies import source_closure
    from .studies.runtime import Definition

    support = average.support
    base = root/'data'/(ID+'-inputs')
    if base.exists() or (root/'data'/ID).exists():
        raise ValueError('use the existing common force witness freeze')
    staged = {}
    with closing(ArchiveStore(root)) as store:
        catalog = store.catalog()

        def read(path):
            return store._read(path, catalog)

        raw = {path: read(path) for stage in (support, average, covariance)
               for path in (stage.OUTPUT, stage.FREEZE, stage.RESULT)}
        covariance._source_receipts(raw)
        for stage in (covariance, gain):
            source_receipt = read(stage.RESULT)
            receipt = json.loads(source_receipt)
            if digest(read(stage.FREEZE)) != receipt['freeze_sha256']:
                raise ValueError('changed force calibration or covariance freeze')
            if stage == covariance and digest(raw[stage.OUTPUT]) != receipt['output_sha256']:
                raise ValueError('changed covariance projection output')
            staged['parent-'+Path(stage.RESULT).name] = source_receipt
        earlier = json.loads(read(support.RECEIPT))
        gps_raw = read(support.WINDOWS)
        if digest(gps_raw) != json.loads(read(support.WINDOW_RECEIPT))['output_sha256']:
            raise ValueError('changed selected receiver windows')
        gps = {(row['segment_id'], row['gps_millisecond_tag']): row for row in average._table(gps_raw)
               if float(row['half_window_s']) == support.HALF_WINDOW_S}
        averaged = {(row['segment_id'], row['gps_millisecond_tag'], row['clock']): row
                    for row in average._table(raw[average.OUTPUT]) if row['gps_stream'] == 'onboard'}
        sigmas = {(row['segment_id'], row['gps_millisecond_tag']): row
                  for row in average._table(raw[covariance.OUTPUT])}
        packets = [row for row in average._table(raw[support.OUTPUT]) if row['state'] == 'supported']
        gains = json.loads(staged['parent-'+Path(gain.RESULT).name])['by_recorder_model']
        if len(packets) != len(sigmas) or len(packets) != sum(WINDOWS.values()):
            raise ValueError('unchanged 991-window support required')
        for case in earlier['recordings']:
            segment, imu = case['segment_id'], str(case['imu_type'])
            pieces = []
            for role in ('training.json', 'scoring.json'):
                entry = case['artifacts'][role]
                content = read(entry['path'])
                if digest(content) != entry['sha256']:
                    raise ValueError('changed earlier or later saved receiver coordinates')
                pieces.append(json.loads(content))
            def joined(key):
                return pieces[0][key]+pieces[1][key]
            tags, times = joined('gps_tags_ms'), joined('query_times_s')
            indices = {int(value): index for index, value in enumerate(tags)}
            windows = []
            for packet in (row for row in packets if row['segment_id'] == segment):
                tag = packet['gps_millisecond_tag']
                ref, variance = gps[segment, tag], sigmas[segment, tag]
                clock_rows = {}
                for clock in support.CLOCKS:
                    row = averaged[segment, tag, clock]
                    if row['side'] != packet['side'] or variance['side'] != packet['side']:
                        raise ValueError('saved supports disagree about earlier and later positions')
                    clock_rows[clock] = dict(interval=[float(row[key]) for key in ('interval_start_s','interval_end_s')],
                        acceleration_lower_mps2=float(packet[clock+'_lower_mps2']),
                        prediction_upper_mps2={m: float(row[m+'_upper_mps2']) for m in average.MATCHED_MODELS},
                        sigma_mps2={m: float(variance[clock+'_'+m+'_sigma_mps2']) for m in average.MATCHED_MODELS})
                windows.append(dict(first=indices[int(ref['first_used_tag'])], last=indices[int(ref['last_used_tag'])],
                    target=indices[int(tag)], sample_count=int(ref['sample_count']), side=packet['side'], clocks=clock_rows))
            if len(windows) != WINDOWS[imu] or len(indices) != len(tags) or not np.isfinite(times).all():
                raise ValueError('same per-recording window inventory required')
            staged['imu'+imu+'.json'] = encoded(dict(imu_type=imu, segment_id=segment, times=times, tags=tags,
                coordinates=pieces[0]['coordinates']['onboard']+pieces[1]['coordinates']['onboard'],
                cut=case['training_epochs'], windows=windows,
                gains={row['model']: row['training_gain'] for row in gains if str(row['imu_type']) == imu}))
    base.mkdir(parents=True)
    inputs = {'plan': PLAN}
    for name, raw in staged.items():
        path = base/name
        atomic(path, raw)
        inputs[path.stem] = path.relative_to(root).as_posix()
    adapter = Path(__file__).relative_to(root).as_posix()
    manifest = Definition.from_dict(dict(id=ID, scope=SCOPE, adapter=adapter, inputs=inputs, tasks=tasks(),
        workers=2, threads=1, maximum_wall_s=120., sources=source_closure(root, [adapter, PLAN])), root).prepare(root)
    print(json.dumps(dict(study=ID, limits=manifest['limits']), sort_keys=True))


if __name__ == '__main__':
    prepare(Path.cwd())
